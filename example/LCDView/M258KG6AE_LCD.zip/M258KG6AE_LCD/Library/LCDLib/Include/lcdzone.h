/**************************************************************************//**
 * @file     lcdzone.h
 * @version  V1.00
 * @brief    RHE6616TP01(8-COM, 40-SEG, 1/4 Bias) LCD zone header file
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#ifndef __LCDZONE_H
#define __LCDZONE_H

#ifdef __cplusplus
extern "C"
{
#endif

/** @addtogroup Library Library
  @{
*/

/** @addtogroup LCDLIB LCD Library
  @{
*/

/** @addtogroup LCDLIB_EXPORTED_CONSTANTS LCD Zone Exported Constants
  @{
*/
/*---------------------------------------------------------------------------------------------------------*/
/*  Digit Zone Constant Definitions                                                                        */
/*---------------------------------------------------------------------------------------------------------*/
#define ZONE_TIME_DIGIT										0


/*---------------------------------------------------------------------------------------------------------*/
/*  COM and SEG Position of Symbol Constant Definitions                                                    */
/*---------------------------------------------------------------------------------------------------------*/
#define SYMBOL_NVT										((4)<<4 | (0)<<0)
#define SYMBOL_P1										((7)<<4 | (7)<<0)
#define SYMBOL_P2										((7)<<4 | (7)<<0)
#define SYMBOL_S7_START										((4)<<4 | (1)<<0)
#define SYMBOL_S6_MINUTE										((4)<<4 | (2)<<0)
#define SYMBOL_S5_HOUR										((4)<<4 | (3)<<0)
#define SYMBOL_S4_TIMER										((4)<<4 | (4)<<0)
#define SYMBOL_S2_CANCEL										((4)<<4 | (6)<<0)
#define SYMBOL_S3_KEEPWARM										((4)<<4 | (5)<<0)
#define SYMBOL_S8_RICE_CATEGORY										((3)<<4 | (6)<<0)
#define SYMBOL_S11_SHSHI_RICE_F										((3)<<4 | (3)<<0)
#define SYMBOL_S12_BROWN_RICE_F										((3)<<4 | (2)<<0)
#define SYMBOL_S13_STICKY_RICE_F										((3)<<4 | (1)<<0)
#define SYMBOL_S14_MIXED_RICE_F										((3)<<4 | (0)<<0)
#define SYMBOL_S21_PROC_CATEGORY										((2)<<4 | (6)<<0)
#define SYMBOL_S22_PREMIUM_F										((1)<<4 | (6)<<0)
#define SYMBOL_S30_SOFTER_F										((1)<<4 | (7)<<0)
#define SYMBOL_S25_SLOW_COOK_F										((1)<<4 | (0)<<0)
#define SYMBOL_S33_HARDER_F										((1)<<4 | (1)<<0)
#define SYMBOL_S23_REGULAR_F										((1)<<4 | (5)<<0)
#define SYMBOL_S24_QUICK_F										((1)<<4 | (3)<<0)
#define SYMBOL_S31_PORRIDGE_F										((1)<<4 | (4)<<0)
#define SYMBOL_S32_CRISPY_F										((1)<<4 | (2)<<0)
#define SYMBOL_S15_WHITE_RICE										((2)<<4 | (5)<<0)
#define SYMBOL_S16_UNWASHED_RICE										((2)<<4 | (4)<<0)
#define SYMBOL_S17_SUSHI_RICE										((2)<<4 | (3)<<0)
#define SYMBOL_S18_BROWN_RICE										((2)<<4 | (2)<<0)
#define SYMBOL_S19_STICKY_RICE										((2)<<4 | (1)<<0)
#define SYMBOL_S20_MIXED_RICE										((2)<<4 | (0)<<0)
#define SYMBOL_S26_PREMIUM_PROC								((0)<<4 | (6)<<0)
#define SYMBOL_S27_RIGULAR_PROC										((0)<<4 | (5)<<0)
#define SYMBOL_S28_QUICK_PROC										((0)<<4 | (3)<<0)
#define SYMBOL_S29_SLOW_PROC										((0)<<4 | (0)<<0)
#define SYMBOL_S34_SOFTER_PROC										((0)<<4 | (7)<<0)
#define SYMBOL_S35_PORRIDGE_PROC										((0)<<4 | (4)<<0)
#define SYMBOL_S36_CRISPY_PROC										((0)<<4 | (2)<<0)
#define SYMBOL_S37_HARDER_PROC										((0)<<4 | (1)<<0)
#define SYMBOL_S10_UNWASHED_RICE_F										((3)<<4 | (4)<<0)
#define SYMBOL_S9_WHITE_RICE_F										((3)<<4 | (5)<<0)


/*@}*/ /* end of group LCDLIB_EXPORTED_CONSTANTS */



/** @addtogroup LCDLIB_EXPORTED_STRUCTS LCD Zone Exported Structs
  @{
 */
typedef struct
{
    unsigned char   u8LCDDispTableNum;          /*!< LCD Display Table Number */
    unsigned char   u8GetLCDComSegNum;          /*!< LCD Com Seg Table Number */
    unsigned short  *pu16LCDDispTable;          /*!< LCD Display Table Pointer */
    unsigned char   *pu8GetLCDComSeg;           /*!< LCD Com Seg Table Pointer */

} LCD_ZONE_INFO_T;

/*@}*/ /* end of group LCDLIB_EXPORTED_STRUCTS */



/** @addtogroup LCDLIB_EXPORTED_CONSTANTS LCD Zone Exported Constants
  @{
*/

#define ZONE_TIME_DIG_CNT										4
#define ZONE_TIME_SEG_NUM										7



/*@}*/ /* end of group LCDLIB_EXPORTED_CONSTANTS */


/** @addtogroup LCDLIB_EXPORTED_STRUCTS LCD Zone Exported Structs
  @{
 */

/**************************************************************************//**
*
* Defines each text's segment (alphabet+numeric) in terms of COM and SEG numbers,
* Using this way that text segment can be consisted of each bit in the
* following bit pattern:
*
*              A
*         -----------
*         |\   |   /|
*         F G  H  I B
*         |  \ | /  |
*         --J-- --K--
*         |   /| \  |
*         E  L M  N C
*         | /  |   \|
*         -----------
*              D
*
*              0
*         -----------
*         |\   |   /|
*        5| 6  7  8 |1
*         |  \ | /  |
*         --9-- -10--
*         |   /| \  |
*        4| 11 12 13|2
*         | /  |   \|
*         -----------
*              3
*
*****************************************************************************/


/**************************************************************************//**
*
* Defines each text's segment (numeric) in terms of COM and BIT numbers,
* Using this way that text segment can be consisted of each bit in the
* following bit pattern:
*
*         ---A---
*         |     |
*         F     B
*         |     |
*         ---G---
*         |     |
*         E     C
*         |     |
*         ---D---
*
*         ---0---
*         |     |
*         5     1
*         |     |
*         ---6---
*         |     |
*         4     2
*         |     |
*         ---3---
*
*****************************************************************************/

static const char acTIMEDigitRawData[ZONE_TIME_DIG_CNT][ZONE_TIME_SEG_NUM][2] =
{
	{
		{0, 8}, 		{1, 8}, 		{4, 8}, 		{6, 8}, 		{5, 8}, 		{2, 8}, 		{3, 8}, 
	},
	{
		{0, 7}, 		{1, 7}, 		{4, 7}, 		{6, 7}, 		{5, 7}, 		{2, 7}, 		{3, 7}, 
	},
	{
		{0, 6}, 		{1, 6}, 		{4, 6}, 		{6, 6}, 		{5, 6}, 		{2, 6}, 		{3, 6}, 
	},
	{
		{0, 5}, 		{1, 5}, 		{4, 5}, 		{6, 5}, 		{5, 5}, 		{2, 5}, 		{3, 5}, 
	},
};

/**************************************************************************//**
*
* Defines segments for the alphabet - ASCII table 0x20 to 0x7A
* Bit pattern below defined for alphabet (text segments)
*
*****************************************************************************/


/**************************************************************************//**
* Defines segments for the numeric display
*****************************************************************************/

static const unsigned short auTIMEDigitMap[] =
{
    0x3F, /* 0 */
    0x06, /* 1 */
    0x5B, /* 2 */
    0x4F, /* 3 */
    0x66, /* 4 */
    0x6D, /* 5 */
    0x7D, /* 6 */
    0x07, /* 7 */
    0x7F, /* 8 */
    0x6F, /* 9 */
};

static const LCD_ZONE_INFO_T g_LCDZoneInfo[] =
{
		{ZONE_TIME_DIG_CNT,			ZONE_TIME_SEG_NUM,			(unsigned short *)auTIMEDigitMap,			(unsigned char *)acTIMEDigitRawData},

};

/*@}*/ /* end of group LCDLIB_EXPORTED_STRUCTS */

/*@}*/ /* end of group LCDLIB */
    
/*@}*/ /* end of group Library */
    
#ifdef __cplusplus
}
#endif
    
#endif  /* __LCDZONE_H */