///******************************************************************************
// * @file     RTC.c
// * @version  V1.00
// * @brief    RTC function
// *
// *
// * @copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
// *
// *****************************************************************************/
//

#include "NuMicro.h"
#include "..\NU_M258KG.h"

#define T_60SEC     60 //60Sec
#define T_60MINS     60 //60Mins

volatile int32_t  g_i32Alarm  = FALSE, g_i32RTCSetMode  = FALSE;

S_RTC_TIME_DATA_T sCurTime = {0};
S_RTC_TIME_DATA_T sBakTime = {0};

void RTC_IRQHandler(void)
{
    if ((RTC->INTEN & RTC_INTEN_ALMIEN_Msk) && (RTC->INTSTS & RTC_INTSTS_ALMIF_Msk))          /* alarm interrupt occurred */
    {
        g_i32Alarm = TRUE;
        RTC_CLEAR_ALARM_INT_FLAG();
    }
}

void RTC_Update(void)
{
    sCurTime.u32Minute = sCurTime.u32Minute + 1;

    //sCurTime.u32Second = sCurTime.u32Second + 2;

    if (sCurTime.u32Second >= T_60SEC)
    {
        sCurTime.u32Minute = sCurTime.u32Minute + (sCurTime.u32Second / T_60SEC);
        sCurTime.u32Second = sCurTime.u32Second % T_60SEC;
    }

    if (sCurTime.u32Minute >= T_60SEC)
    {
        sCurTime.u32Hour = sCurTime.u32Hour + (sCurTime.u32Minute / T_60SEC);
        sCurTime.u32Minute = sCurTime.u32Minute % T_60MINS;
    }

    if (sCurTime.u32Hour >= 24)
    {
        sCurTime.u32Hour -= 24;
    }

    /* Set the alarm time */
    RTC_SetAlarmDateAndTime(&sCurTime);
}

void RTC_Init(void)
{
    S_RTC_TIME_DATA_T sInitTime;

		sInitTime.u32Year       = 2023;
		sInitTime.u32Month      = 9;
		sInitTime.u32Day        = 4;
		sInitTime.u32Hour       = 19;
		sInitTime.u32Minute     = 8;
		sInitTime.u32Second     = 2;
		sInitTime.u32DayOfWeek  = RTC_MONDAY;

    sInitTime.u32TimeScale  = RTC_CLOCK_24;
    RTC_Open(&sInitTime);

    g_i32Alarm = FALSE;

    /* Get the current time */
    RTC_GetDateAndTime(&sCurTime);

    LCD_DisplyTime(sCurTime.u32Hour, sCurTime.u32Minute);

    /* The alarm time setting */
    RTC_Update();

    /* Clear interrupt status */
    RTC->INTSTS = RTC_INTSTS_ALMIF_Msk;

    /* Enable RTC Alarm Interrupt */
    RTC_EnableInt(RTC_INTEN_ALMIEN_Msk);

    NVIC_EnableIRQ(RTC_IRQn);

}