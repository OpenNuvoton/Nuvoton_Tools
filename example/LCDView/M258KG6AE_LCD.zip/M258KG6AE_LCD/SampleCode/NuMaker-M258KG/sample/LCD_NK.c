/**************************************************************************//**
 * @file     LCD_NK.c
 * @version  V1.00
 * @brief    LCD Initial & Frame config.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include "NuMicro.h"
#include "NU_M258KG.h"
#include "tklib.h"
#include "lcdlib.h"

static S_LCD_CFG_T g_LCDCfg =
{
    __LIRC,                     /*!< LCD clock source frequency */
    LCD_COM_DUTY_1_8,           /*!< COM duty */
    LCD_BIAS_LV_1_4,            /*!< Bias level */
    64,                         /*!< Operation frame rate */
    LCD_WAVEFORM_TYPE_B_NORMAL, /*!< Waveform type */
    LCD_DISABLE_ALL_INT,        /*!< Interrupt source */
    LCD_HIGH_DRIVING_OFF_AND_BUF_ON, /*!< Driving mode */
    LCD_VOLTAGE_SOURCE_CP,      /*!< Voltage source */
};

void LCD_Init(void)
{
    /*
        Summary of LCD pin usage:
            COM 0~3   : PB.5, PB.4, PB.3, PB.2
            COM 4~5   : PD.11, PD.10
            COM 6~7   : PE.13, PC.8
            SEG 0~1   : PB.0, PB.1
            SEG 2~3   : PC.9, PC.10
            SEG 4~8  : PB.6, PB.7, PB.8, PB.9, PB.10

    */

    /* Configure LCD multi-function pins */

    /* COM 0~3 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB5MFP_Msk | SYS_GPB_MFPL_PB4MFP_Msk | SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk)) |
                    (SYS_GPB_MFPL_PB5MFP_LCD_COM0 | SYS_GPB_MFPL_PB4MFP_LCD_COM1 | SYS_GPB_MFPL_PB3MFP_LCD_COM2 | SYS_GPB_MFPL_PB2MFP_LCD_COM3);
    /* COM 4~5 */
    SYS->GPD_MFPH = (SYS->GPD_MFPH & ~(SYS_GPD_MFPH_PD10MFP_Msk | SYS_GPD_MFPH_PD11MFP_Msk)) |
                    (SYS_GPD_MFPH_PD11MFP_LCD_COM4 | SYS_GPD_MFPH_PD10MFP_LCD_COM5);
    /* COM 6 */
    SYS->GPE_MFPH = (SYS->GPE_MFPH & ~(SYS_GPE_MFPH_PE13MFP_Msk)) |
                    (SYS_GPE_MFPH_PE13MFP_LCD_COM6);
    /* COM 7 */
    SYS->GPC_MFPH = (SYS->GPC_MFPH & ~(SYS_GPC_MFPH_PC8MFP_Msk)) |
                    (SYS_GPC_MFPH_PC8MFP_LCD_COM7);

    /* SEG 0~1 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB0MFP_Msk | SYS_GPB_MFPL_PB1MFP_Msk)) |
                    (SYS_GPB_MFPL_PB0MFP_LCD_SEG0 | SYS_GPB_MFPL_PB1MFP_LCD_SEG1);
    /* SEG 2~3 */
    SYS->GPC_MFPH = (SYS->GPC_MFPH & ~(SYS_GPC_MFPH_PC9MFP_Msk | SYS_GPC_MFPH_PC10MFP_Msk)) |
                    (SYS_GPC_MFPH_PC9MFP_LCD_SEG2 | SYS_GPC_MFPH_PC10MFP_LCD_SEG3);
    /* SEG 4~8 */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB6MFP_Msk | SYS_GPB_MFPL_PB7MFP_Msk)) |
                    (SYS_GPB_MFPL_PB6MFP_LCD_SEG4 | SYS_GPB_MFPL_PB7MFP_LCD_SEG5);
    SYS->GPB_MFPH = (SYS->GPB_MFPH & ~(SYS_GPB_MFPH_PB8MFP_Msk | SYS_GPB_MFPH_PB9MFP_Msk | SYS_GPB_MFPH_PB10MFP_Msk)) |
                    (SYS_GPB_MFPH_PB8MFP_LCD_SEG6 | SYS_GPB_MFPH_PB9MFP_LCD_SEG7 | SYS_GPB_MFPH_PB10MFP_LCD_SEG8);

    /* Reset LCD module */
    SYS_ResetModule(LCD_RST);

    /* Output Setting Select */
    LCD_OUTPUT_SET(LCD_OUTPUT_SEL8_TO_COM4 | LCD_OUTPUT_SEL9_TO_COM5 | LCD_OUTPUT_SEL14_TO_COM6 | LCD_OUTPUT_SEL15_TO_COM7 |
                   LCD_OUTPUT_SEL47_TO_SEG8 | LCD_OUTPUT_SEL48_TO_SEG7 | LCD_OUTPUT_SEL49_TO_SEG6);

    /* LCD Initialize and calculate real frame rate */
    LCD_Open(&g_LCDCfg);

    /* Select output voltage level 9 for 4.8V */
    LCD_SET_CP_VOLTAGE(LCD_CP_VOLTAGE_LV_9);
}

//----------------------------------------------------------------------------------------------//
void LCD_Init_Setting(void)
{

    /* Init LCD multi-function pins and settings */
    LCD_Init();

    /* Enable LCD display */
    LCD_ENABLE_DISPLAY();
}

void LCD_frame1(void)
{

}

void LCD_frame2(void)
{

}
void LCD_PowerOn(void)
{
    LCDLIB_SetSymbol(SYMBOL_NVT, 1);//Logo_Nuvoton
    LCDLIB_SetSymbol(SYMBOL_S7_START, 1);//Start
    LCDLIB_SetSymbol(SYMBOL_S2_CANCEL, 1);//Cancel
    LCDLIB_SetSymbol(SYMBOL_S5_HOUR, 1);//Hour
    LCDLIB_SetSymbol(SYMBOL_S4_TIMER, 1);//Timer
    LCDLIB_SetSymbol(SYMBOL_S6_MINUTE, 1);//Minute
    LCDLIB_SetSymbol(SYMBOL_S3_KEEPWARM, 1);//KeepWarm

    LCDLIB_SetSymbol(SYMBOL_P1, 1);//Point 1
    LCDLIB_SetSymbol(SYMBOL_P2, 1);//Point 2

    //Type of Rice
    LCDLIB_SetSymbol(SYMBOL_S15_WHITE_RICE, 1);//White Rice
    LCDLIB_SetSymbol(SYMBOL_S16_UNWASHED_RICE, 1);//Unwashed Rice
    LCDLIB_SetSymbol(SYMBOL_S17_SUSHI_RICE, 1);//Sushi Rice
    LCDLIB_SetSymbol(SYMBOL_S18_BROWN_RICE, 1);//Brown Rice
    LCDLIB_SetSymbol(SYMBOL_S19_STICKY_RICE, 1);//Sticky Rice
    LCDLIB_SetSymbol(SYMBOL_S20_MIXED_RICE, 1);//Mixed Rice

    //Type of Process
    LCDLIB_SetSymbol(SYMBOL_S26_PREMIUM_PROC, 1);//Premium
    LCDLIB_SetSymbol(SYMBOL_S27_RIGULAR_PROC, 1);//Regular
    LCDLIB_SetSymbol(SYMBOL_S28_QUICK_PROC, 1);//Quick
    LCDLIB_SetSymbol(SYMBOL_S29_SLOW_PROC, 1);//Slow
    LCDLIB_SetSymbol(SYMBOL_S34_SOFTER_PROC, 1);//Softer
    LCDLIB_SetSymbol(SYMBOL_S35_PORRIDGE_PROC, 1);//Porridge
    LCDLIB_SetSymbol(SYMBOL_S36_CRISPY_PROC, 1);//Crispy Rice
    LCDLIB_SetSymbol(SYMBOL_S37_HARDER_PROC, 1);//Harder

    //Category
    LCDLIB_SetSymbol(SYMBOL_S8_RICE_CATEGORY, 1);//Category of Rice
    LCDLIB_SetSymbol(SYMBOL_S21_PROC_CATEGORY, 1);//Category of Process


    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 1);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 1);//Premium Frame
}

void LCD_Untouched(void)
{
    LCDLIB_SetSymbol(SYMBOL_S7_START, 1);//Start
    LCDLIB_SetSymbol(SYMBOL_S2_CANCEL, 1);//Cancel
    LCDLIB_SetSymbol(SYMBOL_S5_HOUR, 1);//Hour
    LCDLIB_SetSymbol(SYMBOL_S4_TIMER, 1);//Timer
    LCDLIB_SetSymbol(SYMBOL_S6_MINUTE, 1);//Minute
    LCDLIB_SetSymbol(SYMBOL_S3_KEEPWARM, 1);//KeepWarm
}

void LCD_StartTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S7_START, 0);//Start
}


void LCD_CancelTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S2_CANCEL, 0);//Cancel
}

void LCD_TimerTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S4_TIMER, 0);//Timer
}

void LCD_MinTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S6_MINUTE, 0);//Minute
}

void LCD_HourTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S5_HOUR, 0);//Hour
}

void LCD_KeepWarmTrig(void)
{
    LCDLIB_SetSymbol(SYMBOL_S3_KEEPWARM, 0);//KeepWarm
}

void LCD_DisplyTime(uint32_t u32Hour, uint32_t u32Mins)
{
    // show time
    LCDLIB_PrintNumber(ZONE_TIME_DIGIT, (u32Hour * 100 + u32Mins));
}

void LCD_DisplyTime_Off(void)
{
    unsigned char index, i;
    uint8_t com, seg;

    for (index = 0; index <= 3; index++)
    {
        for (i = 0; i < g_LCDZoneInfo[ZONE_TIME_DIGIT].u8GetLCDComSegNum; i++)
        {
            seg = *(g_LCDZoneInfo[ZONE_TIME_DIGIT].pu8GetLCDComSeg
                    + index * g_LCDZoneInfo[ZONE_TIME_DIGIT].u8GetLCDComSegNum * 2
                    + i * 2 + 1);
            com = *(g_LCDZoneInfo[ZONE_TIME_DIGIT].pu8GetLCDComSeg
                    + index * g_LCDZoneInfo[ZONE_TIME_DIGIT].u8GetLCDComSegNum * 2
                    + i * 2 + 0);

            LCD_SetPixel(com, seg, 0);
        }
    }
}