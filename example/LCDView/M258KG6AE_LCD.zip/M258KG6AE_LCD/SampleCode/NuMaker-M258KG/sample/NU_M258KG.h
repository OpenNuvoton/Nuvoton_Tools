/**************************************************************************//**
 * @file     NU_M258KG.h
 * @version  V1.00
 * @brief    For NuMaker-M258KG header file.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef _NU_M258_KG_H_
#define _NU_M258_KG_H_

//Bit0: Start;  Bit1: Timer; Bit2: Hour; Bit3: Min; Bit4: Keep Warm; Bit5: Cancel
#define TOUCH_TK_START 0x01
#define TOUCH_TK_TIMER 0x02
#define TOUCH_TK_HOUR 0x04
#define TOUCH_TK_MIN 0x08
#define TOUCH_TK_KEEPWARM 0x10
#define TOUCH_TK_CANCEL 0x20


enum PROCESS {Premium = 0, Regular, Quick, Slow, Softer, Porridge, Crispy, Harder};

/* System Setting */
struct SYS_Setting_Tag;

typedef struct SYS_Setting_Tag
{
    uint8_t   FunKey;//Bit0: Start;  Bit1: Timer; Bit2: Hour; Bit3: Min; Bit4: Keep Warm; Bit5: Cancel
    uint8_t   Process;//0: Premium; 1: Regular; 2: Quick; 3: Slow Cook; 4: Softer; 5: Porridge 6:Crispy Rice; 7:Harder
} SYS_Setting_T;

typedef enum
{
    eMAIN_APP_IDLE_STATE,
    eMAIN_APP_TK_STATE,
} E_MAIN_APP_STATE;

extern S_RTC_TIME_DATA_T sCurTime, sBakTime;
extern volatile int32_t  g_i32Alarm, g_i32RTCSetMode;
extern volatile SYS_Setting_T SysSetting;

void RTC_Init(void);
void RTC_Update(void);

void LCD_Init_Setting(void);
void LCD_frame1(void);
void LCD_frame2(void);
void LCD_DisplyTime(uint32_t u32Hour, uint32_t u32Mins);
void LCD_DisplyCountdownTimer(uint32_t u32Min);
void LCD_PowerOn(void);
void LCD_Untouched(void);
void LCD_StartTrig(void);
void LCD_CancelTrig(void);
void LCD_TimerTrig(void);
void LCD_MinTrig(void);
void LCD_HourTrig(void);
void LCD_KeepWarmTrig(void);
void LCD_DisplyTime_Off(void);

void SPI0_Init(void);
void ISD_PWR_UP(void);
void ISD_PLAY_VP(int IDX_ADDR);

/* TK_Command.c */
typedef void(*VoidFunc)(void);
extern VoidFunc TKFunc[26];
#endif
