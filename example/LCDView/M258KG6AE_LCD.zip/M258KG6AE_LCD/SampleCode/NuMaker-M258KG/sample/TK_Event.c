///******************************************************************************
// * @file     TK_Command.c
// * @version  V1.00
// * @brief    Touch-key function
// *
// *
// * @copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
// *
// *****************************************************************************/
//
#include "NuMicro.h"
#include "TK_Demo.h"
#include "NU_M258KG.h"
#include "lcdlib.h"

////-----------------------------------------------------------------------------
//// Variable Declaration
////-----------------------------------------------------------------------------
volatile SYS_Setting_T SysSetting;
// Premiun, Regular, Quick, SlowCook, Softer, Porridge, Cruspy Rice, Harder
uint8_t g_au8CookingTimeArray[8] = {2, 1, 0, 3, 4, 5, 6, 7};//Minutes

// a dummy function
void null_func(void)
{
    return;
}

/*---------------------------------------------------------------------------------------------------------*/
/* Touch event                                                                                                                                       */
/*---------------------------------------------------------------------------------------------------------*/

void tk_func1(void)//S29 SlowCook
{
    SysSetting.Process = Slow;
    LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
    LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
    LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
    LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 1);//SlowCook Frame
    LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
    LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
    LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
    LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame

    return;
}

void tk_func2(void)//S24 Quick
{
    SysSetting.Process = Quick;
    LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
    LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
    LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 1);//Quick Frame
    LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
    LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
    LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
    LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
    LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame

    return;
}

void tk_func3(void)//S12 Brown Rice
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 0);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 0);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 0);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 1);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 0);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 0);//Mixed Rice Frame

    return;
}

void tk_func4(void)//S19 Sticky Rice
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 0);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 0);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 0);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 0);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 1);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 0);//Mixed Rice Frame

    return;
}

void tk_func5(void)
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 0);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 0);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 0);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 0);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 0);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 1);//Mixed Rice Frame
    return;
}

void tk_func6(void)//S5 Hour
{
    if ((SysSetting.FunKey & 0x03) == 0x02) //ONLY TK_TIMER is pressed -> Setting Reserved Timer
    {
        sBakTime.u32Hour = (sBakTime.u32Hour == 23) ? 0 : (sBakTime.u32Hour + 1);
        LCD_DisplyTime(sBakTime.u32Hour, sBakTime.u32Minute);

        LCD_HourTrig();
    }

    return;
}

void tk_func7(void)//S6 Mins
{
    if ((SysSetting.FunKey & 0x03) == 0x02) //ONLY TK_TIMER is pressed -> Setting Reserved Timer
    {
        sBakTime.u32Minute = (sBakTime.u32Minute == 59) ? 0 : (sBakTime.u32Minute + 1);
        LCD_DisplyTime(sBakTime.u32Hour, sBakTime.u32Minute);

        LCD_MinTrig();
    }

    return;
}

void tk_func8(void)//S7 Start
{
    SysSetting.FunKey |= TOUCH_TK_START;//Bit0: Start;  Bit1: Timer; Bit2: Hour; Bit3: Min; Bit4: Keep Warm; Bit5: Cancel

    if ((SysSetting.FunKey & 0x03) == 1) //ONLY TK_START is pressed -> Countdown Timer
    {
        TickClearTick(1);
        TickClearTick(2);
        sBakTime.u32Minute = g_au8CookingTimeArray[SysSetting.Process];
				if(sBakTime.u32Minute > 0)  LCD_DisplyTime(0, sBakTime.u32Minute);

    }
    else//TK_START & TK_Timer are pressed. -> Reserved Time
    {
        LCD_DisplyTime(sBakTime.u32Hour, sBakTime.u32Minute);
    }

    LCD_StartTrig();

    return;
}

void tk_func9(void)
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 1);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 0);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 0);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 0);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 0);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 0);//Mixed Rice Frame

    return;
}
void tk_func10(void)
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 0);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 1);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 0);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 0);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 0);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 0);//Mixed Rice Frame

    return;
}

void tk_func11(void)
{
    LCDLIB_SetSymbol(SYMBOL_S9_WHITE_RICE_F, 0);//White Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S10_UNWASHED_RICE_F, 0);//Unwashed Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S11_SHSHI_RICE_F, 1);//Sushi Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S12_BROWN_RICE_F, 0);//Brown Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S13_STICKY_RICE_F, 0);//Sticky Rice Frame
    LCDLIB_SetSymbol(SYMBOL_S14_MIXED_RICE_F, 0);//Mixed Rice Frame

    return;
}

void tk_func12(void)//S23 Regular
{
    //  if ((SysSetting.FunKey & 0x01) == 0)
    {
        SysSetting.Process = Regular;
        LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
        LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 1);//Regular Frame
        LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
        LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
        LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
        LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
        LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
        LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame
    }

    return;
}

void tk_func15(void)
{
    //  if ((SysSetting.FunKey & 0x01) == 0)
    {
        SysSetting.Process = Porridge;
        LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
        LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
        LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
        LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
        LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
        LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 1);//Porridge Frame
        LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
        LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame
    }

    return;
}

void tk_func19(void)
{
    SysSetting.Process = Crispy;
    LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
    LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
    LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
    LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
    LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
    LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
    LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 1);//Crispy Frame
    LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame

    return;
}

void tk_func20(void)
{
    SysSetting.Process = Harder;
    LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
    LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
    LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
    LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
    LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
    LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
    LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
    LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 1);//Harder Frame

    return;
}

void tk_func21(void)//S2 Cancel
{
    SysSetting.FunKey &= 0xFC;//Bit0: Start;  Bit1: Timer; Bit2: Hour; Bit3: Min; Bit4: Keep Warm; Bit5: Cancel

    /* Get the current time */
    RTC_GetDateAndTime(&sCurTime);
    LCD_DisplyTime(sCurTime.u32Hour, sCurTime.u32Minute);

    LCD_CancelTrig();
    return;
}


void tk_func22(void)
{
    LCD_KeepWarmTrig();

    return;
}

void tk_func23(void)//S4 Timer
{
    SysSetting.FunKey |= TOUCH_TK_TIMER;//Bit0: Start;  Bit1: Timer; Bit2: Hour; Bit3: Min; Bit4: Keep Warm; Bit5: Cancel

    /* Get the current time */
    RTC_GetDateAndTime(&sBakTime);
    /* LCD shows Reserved Time Scene */
    LCD_TimerTrig();
    return;
}

void tk_func24(void)
{
    //   if ((SysSetting.FunKey & 0x01) == 0)
    {
        SysSetting.Process = Premium;
        LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 1);//Premium Frame
        LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
        LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
        LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
        LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 0);//Softer Frame
        LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
        LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
        LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame
    }
    return;
}
void tk_func25(void)
{
    //   if ((SysSetting.FunKey & 0x01) == 0)
    {
        SysSetting.Process = Softer;
        LCDLIB_SetSymbol(SYMBOL_S22_PREMIUM_F, 0);//Premium Frame
        LCDLIB_SetSymbol(SYMBOL_S23_REGULAR_F, 0);//Regular Frame
        LCDLIB_SetSymbol(SYMBOL_S24_QUICK_F, 0);//Quick Frame
        LCDLIB_SetSymbol(SYMBOL_S25_SLOW_COOK_F, 0);//SlowCook Frame
        LCDLIB_SetSymbol(SYMBOL_S30_SOFTER_F, 1);//Softer Frame
        LCDLIB_SetSymbol(SYMBOL_S31_PORRIDGE_F, 0);//Porridge Frame
        LCDLIB_SetSymbol(SYMBOL_S32_CRISPY_F, 0);//Crispy Frame
        LCDLIB_SetSymbol(SYMBOL_S33_HARDER_F, 0);//Harder Frame
    }
    return;
}
VoidFunc TKFunc[26] =
{
    &null_func,  &tk_func1,   &tk_func2,  &tk_func3, &tk_func4, &tk_func5, &tk_func6, &tk_func7, &tk_func8, &tk_func9, &tk_func10, &tk_func11, &tk_func12
    , &null_func, &null_func, &tk_func15, &null_func, &null_func, &null_func, &tk_func19, &tk_func20, &tk_func21, &tk_func22, &tk_func23, &tk_func24, &tk_func25
};

