#ifndef TK_COMMAND_H
#define TK_COMMAND_H

#define TK0 0
#define TK1 1
#define TK2 2
#define TK3 3
#define TK4 4
#define TK5 5
#define TK6 6
#define TK7 7
#define TK8 8
#define TK9 9
#define TK10 10
#define TK11 11
#define TK12 12
#define TK13 13
#define TK14 14
void null_func(void);
void tk_func0(void);
void tk_func1(void);
void tk_func2(void);

void tk_func8(void);
void tk_func9(void);
void tk_func10(void);
void tk_func11(void);
void tk_func14(void);

#endif
