/**************************************************************************//**
 * @file     TK_Main.c
 * @version  V1.00
 * @brief    Demonstrate how to calibrate TK14 in the NuMaker-M258KG board.
 *           After the calibration completes, LCD displays M258KG temperature,
 *           firmware version, and TK14 press information.
 *
 * SPDX-License-Identifier: Apache-2.0
 * @copyright (C) 2022 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "NuMicro.h"
#include "tklib.h"
#include "TK_Demo.h"
#include "NU_M258KG.h"

volatile uint8_t u8EventKeyScan = 0;
volatile int8_t i8SliderPercentage = 0;
volatile int8_t i8WheelPercentage = 0;
volatile int8_t i8KeyVal, i8KeyValPre;
volatile uint8_t u8Event1min = 0, u8Event500ms = 0;

#ifdef MASS_FINETUNE
    void TK_MassProduction(int8_t *pai8Signal);
#endif

void TickCallback_KeyScan(void)
{
    u8EventKeyScan = 1;
}

void TickCallback_1min(void)
{
    u8Event1min = 1;
}
void TickCallback_500ms(void)
{
    u8Event500ms = 1;
}

int8_t SliderPercentage(int8_t *pu8SliderBuf, uint8_t u8Count)
{
    int8_t i;
    float i16M = 0.0, i16N = 0.0;

    for (i = 0; i < u8Count; i = i + 1)
    {
        if (pu8SliderBuf[i] > 1)
        {
            i16M += (i + 1) * pu8SliderBuf[i];
            i16N += pu8SliderBuf[i];
        }
    }

    return (int8_t)((((i16M * 10) / i16N) - 10) * 10) / ((u8Count - 1));
}

/**
  *  Report touching or un-touching state depends on debounce parameter you set on calibration stage
  *  For example,
  *      TK_ScanKey() may report someone key pressed but its signal is less than threshold of the key.
  *      The root cause is the key still under de-bounce stage.
  */

#if 0
void TK_RawDataView(void)
{

    int8_t ai8Signal[TKLIB_TOL_NUM_KEY];

    if (u8EventKeyScan == 1)
    {
        u8EventKeyScan = 0;
        /**
          * TK_ScanKey() scan all enable key, slider and wheel channels.
          * i8Ret : Key/slider/wheel channel with max amplitude. -1: means no any key's amplitude over the key's threshold.
          * ai8Signal[]: The buffer size is equal to the M258 TK channels. It reports the signal amplitude on this round
          */
        int8_t i8Ret = TK_ScanKey(&ai8Signal[0]);

        i8KeyVal = i8Ret;

#ifdef MASS_FINETUNE
        TK_MassProduction(ai8Signal);
#endif

        int8_t ai8TmpSignal[TKLIB_TOL_NUM_KEY];

#if defined(OPT_SLIDER)

        {
            /** To save buffer size, re-used the ai8Signal[] buffer
              * Remember that the buffer will be destroied
              */
            uint16_t u16ChnMsk;
            static uint8_t updatecount = 0;

            updatecount = updatecount + 1;

            if (updatecount < 5)
                return;

            updatecount = 0;

            u16ChnMsk = TK_GetEnabledChannelMask(TK_SLIDER);

            if (TK_CheckSliderWheelPressed(TK_SLIDER) == 1)
            {

                uint8_t u8Count = 0, i;

                for (i = 0; i < TKLIB_TOL_NUM_KEY ; i++)
                {
                    if (u16ChnMsk & (1ul << i))
                    {
                        ai8TmpSignal[u8Count] = ai8Signal[i];
                        u8Count = u8Count + 1;
                    }
                }

                i8SliderPercentage = TK_SliderPercentage(ai8TmpSignal, u8Count);
            }

        }
#endif
#if defined(OPT_WHEEL)

        {
            /** To save buffer size, re-used the ai8Signal[] buffer
              * Remember that the buffer will be destroyed
              */

            uint32_t u32ChnMsk = TK_GetEnabledChannelMask(TK_WHEEL);

            if (TK_CheckSliderWheelPressed(TK_WHEEL)  == 1)
            {

                uint8_t i, u8Count = 0;

                for (i = 0; i < TKLIB_TOL_NUM_KEY ; i++)
                {
                    if (u32ChnMsk & (1ul << i))
                    {
                        ai8TmpSignal[u8Count] = ai8Signal[i];
                        u8Count = u8Count + 1;
                    }
                }

                i8WheelPercentage = TK_WheelPercentage(ai8TmpSignal, u8Count);
                DBG_PRINTF("Wheel %d\n", i8WheelPercentage);
            }
        }
#endif

    }

}
#else
int8_t TK_RawDataView(void)
{

    int8_t i8Ret = 0;
    int8_t ai8Signal[TKLIB_TOL_NUM_KEY];

    if (u8EventKeyScan == 1)
    {
        u8EventKeyScan = 0;
        /**
          * TK_ScanKey() scan all enable key, slider and wheel channels.
          * i8Ret : Key/slider/wheel channel with max amplitude. -1: means no any key's amplitude over the key's threshold.
          * ai8Signal[]: The buffer size is equal to the M258 TK channels. It reports the signal amplitude on this round
          */
        i8Ret = TK_ScanKey(&ai8Signal[0]);

        i8KeyVal = i8Ret;
        return i8KeyVal;
    }

    return -1;
}
#endif
void SYS_Init(void)
{

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Unlock protected registers */
    SYS_UnlockReg();

#if (CLK_SOURCE == CLK_HIRC )

    /* Enable HIRC clock (Internal RC 48MHz) */
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);

    /* Wait for HIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Enable external 32768Hz XTAL */
    CLK_EnableXtalRC(CLK_PWRCTL_LXTEN_Msk);

    /* Waiting for clock ready */
    CLK_WaitClockReady(CLK_STATUS_LXTSTB_Msk);


    /* Select HCLK clock source as HIRC and and HCLK source divider as 1 */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HIRC, CLK_CLKDIV0_HCLK(1));

    /* Set both PCLK0 and PCLK1 as HCLK/2 */
    CLK->PCLKDIV = CLK_PCLKDIV_APB0DIV_DIV2 | CLK_PCLKDIV_APB1DIV_DIV2;

    /* Select IP clock source */
    /* Select UART0 clock source is HIRC */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HIRC, CLK_CLKDIV0_UART0(1));

#else

    /* Set XT1_OUT(PF.2) and XT1_IN(PF.3) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE2_Msk | GPIO_MODE_MODE3_Msk);
    /* Enable external 12MHz XTAL */
    CLK_EnableXtalRC(CLK_PWRCTL_HXTEN_Msk);

    /* Waiting for clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Set core clock as PLL_CLOCK from PLL */
    CLK_SetCoreClock(PLL_CLOCK);

    /* Set both PCLK0 and PCLK1 as HCLK */
    CLK->PCLKDIV = CLK_PCLKDIV_APB0DIV_DIV1 | CLK_PCLKDIV_APB1DIV_DIV1;

    /* Select IP clock source */
    /* Select UART0 clock source is HXT */
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL1_UART0SEL_HXT, CLK_CLKDIV0_UART0(1));

    /* Disable digital input path of analog pin XT1_OUT to prevent leakage */
    GPIO_DISABLE_DIGITAL_PATH(PF, (1ul << 2));

    /* Disable digital input path of analog pin XT1_IN to prevent leakage */
    GPIO_DISABLE_DIGITAL_PATH(PF, (1ul << 3));

#endif

    /* Enable LIRC clock (Internal RC 38.4Hz) */
    CLK_EnableXtalRC(CLK_PWRCTL_LIRCEN_Msk);

    /* Wait for LIRC clock ready */
    CLK_WaitClockReady(CLK_STATUS_LIRCSTB_Msk);

    /* Enable UART0 peripheral clock */
    CLK_EnableModuleClock(UART0_MODULE);

#ifdef UART1_DBG
    /* Enable UART1 peripheral clock */
    CLK_EnableModuleClock(UART1_MODULE);
#endif

    /* Enable TIMER0 peripheral clock */
    CLK_EnableModuleClock(TMR0_MODULE);

    /* Enable TIMER1 peripheral clock */
    CLK_EnableModuleClock(TMR1_MODULE);

    /* Enable TIMER2 peripheral clock */
    CLK_EnableModuleClock(TMR2_MODULE);

    /* Enable TK peripheral clock */
    CLK_EnableModuleClock(TK_MODULE);

    /* Enable LCD peripheral clock */
    CLK_EnableModuleClock(LCD_MODULE);

    /* Enable GPIO(PB) peripheral clock */
    CLK_EnableModuleClock(GPB_MODULE);

    /* Enable SPI0 peripheral clock */
    /* Select PCLK0 as the clock source of SPI0 */
    CLK_SetModuleClock(SPI0_MODULE, CLK_CLKSEL2_SPI0SEL_PCLK1, MODULE_NoMsk);
    CLK_EnableModuleClock(SPI0_MODULE);

    /* Enable RTC peripheral clock */
    CLK_EnableModuleClock(RTC_MODULE);

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate PllClock, SystemCoreClock and CycylesPerUs automatically. */
    SystemCoreClockUpdate();

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init I/O Multi-function                                                                                 */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Set PB multi-function pins for UART0 RXD and TXD */
    Uart0DefaultMPF();

#ifdef UART1_DBG
    /* Set GPB multi-function pins for UART1 RXD and TXD */
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~SYS_GPB_MFPL_PB6MFP_Msk) | SYS_GPB_MFPL_PB6MFP_UART1_RXD;
    SYS->GPB_MFPL = (SYS->GPB_MFPL & ~SYS_GPB_MFPL_PB7MFP_Msk) | SYS_GPB_MFPL_PB7MFP_UART1_TXD;
#endif



    /* Set X32_OUT(PF.4) and X32_IN(PF.5) to input mode */
    PF->MODE &= ~(GPIO_MODE_MODE4_Msk | GPIO_MODE_MODE5_Msk);

    /* Disable digital input path of analog pin X32_OUT to prevent leakage */
    GPIO_DISABLE_DIGITAL_PATH(PF, (1ul << 4));

    /* Disable digital input path of analog pin XT32_IN to prevent leakage */
    GPIO_DISABLE_DIGITAL_PATH(PF, (1ul << 5));

}

// int32_t main(void) {
//   while (1) {
//     __NOP();
//   }
// }

int32_t main(void)
{
    uint32_t u32ChanelMsk;
    int8_t i8Ret;

    SYS_Init();

#ifdef  DEMO_CALIBRATION
    UART0_Init();
#endif

#ifdef UART1_DBG
    UART1_Init();
    printf("UART Init!\n");
#endif



    i8Ret = TK_LoadPara(&u32ChanelMsk);


#ifdef DEMO_CALIBRATION

    /* Initialize FMC to Load TK setting and calibration data from flash */
    FMC_Open();
    FMC_ENABLE_AP_UPDATE();

    if (i8Ret == -1)
    {
        /** i8Ret = -1 means that no any calibration data stored in flash
          * If no any data stored in flash. Get TK setting and calibration data from UART port
          * Program will be blocked in the function until received START_CALIBRATION command. The return value will be 1
          */
        i8Ret = TK_GetPacket(&u32ChanelMsk);
    }


    /* Init TK Controller */
    TK_Init();

    /* Initialize Multiple Function Pins for TK */
    SetTkMultiFun(u32ChanelMsk);

    /* Init systick 20ms/tick */
    Init_SysTick();

    /* Initialize LCD pin */
    LCD_Init_Setting(); LCD_SetAllPixels(1);

    /* Install Tick Event Handler To Drive Key Scan */
    TickSetTickEvent(1, (void *)TickCallback_KeyScan);

    do
    {
        if (i8Ret == 1)
        {
            /** Receive Start calibration command
              * The function will be blocked until calibration done
              */
            TK_Calibration_Untouch();
            /* Inform UART module calibration done */
            UART_SetCalibrationDone();
        }

        i8Ret = TK_GetPacket(&u32ChanelMsk);

        /** May change configurations through UART port
          * Init TK Controller again
          */
        TK_Init();

        /* Initialize Multiple Function Pins for TK again */
        SetTkMultiFun(u32ChanelMsk);
    } while (1);

#endif /* DEMO_CALIBRATION */

#ifdef DEMO_FREERUN
    uint8_t g_u8MainState = eMAIN_APP_IDLE_STATE;
    static uint8_t toggle = 0;

    if (i8Ret < 0)
    {
        /* DBG_PRINTF("Please run target TK_Application first to calibrate touchkey\n"); */
        while (1);
    }


    /*---------------------------------------------------------------------------------------------------------*/
    /* Initialize TouchKey                                                                                     */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init TK Controller */
    TK_Init();

    /* Initialize Multiple Function Pins for TK */
    SetTkMultiFun(u32ChanelMsk);

    /* Init systick 20ms/tick */
    Init_SysTick();
    /* Install Tick Event Handler */
    TickSetTickEvent(1, (void *)TickCallback_KeyScan);
    TickSetTickEvent(3000, (void *)TickCallback_1min);
    TickSetTickEvent(25, (void *)TickCallback_500ms);

    /*---------------------------------------------------------------------------------------------------------*/
    /* Initialize LCD                                                                                          */
    /*---------------------------------------------------------------------------------------------------------*/
    /* Initialize LCD pin */
    LCD_Init_Setting();

    /* Init RTC Controller */
    RTC_Init();

    /* LCD shows PowerON Scene */
    LCD_PowerOn();


    g_u8MainState = eMAIN_APP_IDLE_STATE;
    i8KeyValPre = 0xff;

    /* Init systick 20ms/tick */
    Init_SysTick();
    /* Install Tick Event Handler */
    TickSetTickEvent(1, (void *)TickCallback_KeyScan);//EventID = 0;
    TickSetTickEvent(3000, (void *)TickCallback_1min);//EventID = 1;
    TickSetTickEvent(25, (void *)TickCallback_500ms);//EventID = 2;

    GPIO_SetMode(PB, BIT14, GPIO_MODE_QUASI);

    do
    {
#if 1

        /*---------------------------------------------------------------------------------------------------------*/
        /* RTC Routine Process                                                                                     */
        /*---------------------------------------------------------------------------------------------------------*/
        //Routine processes. RTC update alarm time every 1 minute
        if (g_i32Alarm == TRUE)
        {
            RTC_Update();
        }

        switch ((SysSetting.FunKey & 0x03))
        {
            case 0://RTC & LCD Update every 1 minute
                if (g_i32Alarm == TRUE)
                {
                    LCD_DisplyTime(sCurTime.u32Hour, sCurTime.u32Minute);
                }

                break;

            case 1://Countdown timer(RTC & LCD Update every 1 minute)
                    if (sBakTime.u32Minute == 0)
                    {
												TIMER_Delay(TIMER0, 100000);
   

                        SysSetting.FunKey &= 0xFE;
                        /* Get the current time */
                        RTC_GetDateAndTime(&sCurTime);
                        LCD_DisplyTime(sCurTime.u32Hour, sCurTime.u32Minute);
                    }
										else
										{
												if (u8Event1min == 1)
												{
														sBakTime.u32Minute--;
														LCD_DisplyTime(0, sBakTime.u32Minute);
												}
												if ((u8Event500ms == 1) && sBakTime.u32Minute)
												{
														u8Event500ms = 0;

														if (toggle)
														{
																LCD_DisplyTime(0, sBakTime.u32Minute);
														}
														else
														{
																LCD_DisplyTime_Off();
														}

														toggle ^= 1;
												}
									  }

                break;

            case 3://Reserved mode(RTC & LCD don't update)
                if (g_i32Alarm == TRUE)
                {
                    /* Get the current time */
                    RTC_GetDateAndTime(&sCurTime);

                    if (sBakTime.u32Minute == sCurTime.u32Minute && sBakTime.u32Hour == sCurTime.u32Hour)
                    {
                        SysSetting.FunKey &= 0xFC;

                        LCD_DisplyTime(sBakTime.u32Hour, sBakTime.u32Minute);
                    }
                }
                else
                {
                    if (u8Event500ms == 1)
                    {
                        u8Event500ms = 0;

                        if (toggle)
                        {
                            LCD_DisplyTime(sBakTime.u32Hour, sBakTime.u32Minute);
                        }
                        else
                        {
                            LCD_DisplyTime_Off();
                        }

                        toggle ^= 1;
                    }
                }

                break;

            default:
                break;

        }

        //Reset flag
        if (g_i32Alarm == TRUE)
        {
            g_i32Alarm = FALSE;
        }

        if (u8Event1min == 1)
        {
            u8Event1min = 0;
        }

        if (u8Event500ms == 1)
        {
            u8Event500ms = 0;
        }

#endif

#if 1
        /*---------------------------------------------------------------------------------------------------------*/
        /* Touch key process                                                                                             */
        /*---------------------------------------------------------------------------------------------------------*/
        TK_RawDataView();

        if (i8KeyVal != i8KeyValPre)
        {

            /* LCD Display base on TK */
            if ((i8KeyVal != (int8_t)0xff) && (i8KeyVal != (int8_t)0))
            {
                g_u8MainState = eMAIN_APP_TK_STATE;
            }

            i8KeyValPre = i8KeyVal;

            switch (g_u8MainState)
            {
                case eMAIN_APP_IDLE_STATE:
                    PB14 = 1;
                    LCD_Untouched();
                    break;

                case eMAIN_APP_TK_STATE:
                    //   printf("TK[%x]\r", i8KeyValPre);
                    PB14 = 0;

                    switch (i8KeyValPre)
                    {
                        case TK6:
                        case TK7:
                            TickClearTick(2);//u8EventKeyShortPress ID
                            u8Event500ms = 0;
                            (*TKFunc[i8KeyValPre])();

                            do
                            {
                                if (u8Event500ms == 1)
                                {
                                    u8Event500ms = 0;
                                    i8KeyValPre = i8KeyVal;
                                    (*TKFunc[i8KeyValPre])();
                                }

                                TK_RawDataView();

                            } while (i8KeyVal != (int8_t)0xff) ;


                            break;

                        default:
                            (*TKFunc[i8KeyValPre])();
                            break;
                    }


                    g_u8MainState = eMAIN_APP_IDLE_STATE;
                    break;

                default:
                    break;
            }
        }

#endif
    } while (1);

#endif  /* DEMO_FREERUN */


}


